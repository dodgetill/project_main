from flask import Flask, render_template

app = Flask(__name__)

# Временные данные товаров
products = [
    {
        "id": 1,
        "title": "Steam Wallet 1000₽",
        "price": 1000
    },
    {
        "id": 2,
        "title": "Windows 11 Key",
        "price": 2500
    },
    {
        "id": 3,
        "title": "Minecraft Account",
        "price": 399
    }
]

@app.route("/")
def index():
    return render_template("index.html", products=products)

@app.route("/cart")
def cart():
    return render_template("cart.html")

@app.route("/wishlist")
def wishlist():
    return render_template("wishlist.html")

if __name__ == "__main__":
    app.run(debug=True)